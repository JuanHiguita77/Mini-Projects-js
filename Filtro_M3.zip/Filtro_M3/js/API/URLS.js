export const URL = 'http://localhost:3000/';
export const URLCompanies = `${URL}companies`;
export const URLJobs = `${URL}jobs`;
